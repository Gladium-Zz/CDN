<a name="1.0.3"></a>
## [1.0.3](https://github.com/zWingz/picgo-plugin-github-plus/compare/1.0.2...1.0.3) (2019-01-15)


### Bug Fixes

* 🐛 fix devDependencies ([318c8a1](https://github.com/zWingz/picgo-plugin-github-plus/commit/318c8a1))



<a name="1.0.2"></a>
## [1.0.2](https://github.com/zWingz/picgo-plugin-github-plus/compare/1.0.0...1.0.2) (2019-01-15)


### Bug Fixes

* 🐛 package.json files ([81e8864](https://github.com/zWingz/picgo-plugin-github-plus/commit/81e8864))



<a name="1.0.0"></a>
# [1.0.0](https://github.com/zWingz/picgo-plugin-github-plus/compare/e3260c4...1.0.0) (2019-01-15)


### Features

* 🎸 init project ([e3260c4](https://github.com/zWingz/picgo-plugin-github-plus/commit/e3260c4))
* 🎸 release ([114dcfa](https://github.com/zWingz/picgo-plugin-github-plus/commit/114dcfa))



